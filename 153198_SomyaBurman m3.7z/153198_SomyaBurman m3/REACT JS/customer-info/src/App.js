import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

class App extends Component {

  constructor(props) {
    super(props)

  /************  initial login state  ********************/
    this.state = {
      isLoggedIn: false,
      username: '',
      password: ''
    }
  }

/************   login state after input ********************/
  logIn = (event) => {
    event.preventDefault()
    this.setState({
      isLoggedIn: true
    })
  }



/************  changing field values of state objects  ********************/
  usernameChange = (event) => {
    this.setState({
      username: event.target.value
    })
  }


  emailChange = (event) => {
    this.setState({
      email: event.target.value
    })
  }

  mobileChange = (event) => {
    this.setState({
      mobile: event.target.value
    })
  }

  addressChange = (event) => {
    this.setState({
      address: event.target.value
    })
  }

  purposeChange = (event) => {
    this.setState({
      purpose: event.target.value
    })
  }

  dateChange = (event) => {
    this.setState({
      date: event.target.value
    })
  }


/************* to delete user deltails ******************/

  deleteUser = (event) => {
    event.preventDefault()
    this.setState({
      isLoggedIn: true,
      username: '',
      email: '',
      mobile: '',
      address: '',
      purpose: '',
      date: ''

    })
  }

  render() {
    return (

      <div className='App'>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
        {!this.state.isLoggedIn ? (
          <div className='LoggedOut' >
            <div className="grid" className="jumbotron text-center"  >
              <h2>Customer Registration Form</h2>
              <hr/>
              
              <form onSubmit={this.logIn}>
                <label><input type='text'
                  placeholder='Username'
                  value={this.state.username}
                  onChange={this.usernameChange}
                  required
                /></label> <br />

                <label><input type='email'
                  placeholder='Email id'
                  value={this.state.email}
                  onChange={this.emailChange}
                  required />
                  </label> <br />

                <label><input type='number'
                  placeholder='Mobile Number'
                  value={this.state.mobile}
                  onChange={this.mobileChange}
                  required /></label> <br />

                <label><input type='text'
                  placeholder='Address'
                  value={this.state.address}
                  onChange={this.addressChange}
                  required /> </label> <br />

                 <label><input type='text'
                  placeholder='Purpose of visit'
                  value={this.state.purpose}
                  onChange={this.purposeChange}
                  required /> </label> <br />

                 <label><input type='date'
                  placeholder='Date of visit'
                  value={this.state.date}
                  onChange={this.dateChange}
                  required /> </label> <br />

                <br />

                <input type='submit' className="btn btn-info" value='Log In' />
              </form>


            </div>
          </div>
        ) : (<div className="LoggedIn">
          <div className="grid" className="jumbotron text-center"  >
            <h2>Customers visit Information</h2>
              <hr/>
            <p text-align="left">
              Name : {this.state.username} <br />
              Email id : {this.state.email}  <br />
              Mobile Number : {this.state.mobile}  <br />
              Address : {this.state.address}  <br />
              Description/Purpose : {this.state.purpose}  <br />
              Date of Visit : {this.state.date}  <br />
              <br />
              <input type="button" className="btn btn-info" value='delete' onClick={this.deleteUser} />
            </p>
          </div>
        </div>
          )}
      </div>
    );
  }
}

export default App;

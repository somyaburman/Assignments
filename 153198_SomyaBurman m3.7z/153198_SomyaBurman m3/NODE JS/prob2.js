
/**************  Display mobile belonging to specific range  *****************/

var http = require('http');
var express = require('express');
var exp = express();
var parser = require('body-parser')
var fs = require('fs');
var cors = require('cors');

exp.get('/rest/api/load/:price', (req, res) => {

    //empty array to store mobile details belonging to range

    mobArr = []
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With,Content-Type,Accept")

    var raw = fs.readFileSync('mobile.json')
    var data = JSON.parse(raw);
    for (var d of data) {

        if (d.mobPrice >= 10000 && d.mobPrice <= 50000) {
            mobArr.push(d)
        }
    }
    res.status(201).send(mobArr);
    console.log(mobArr)

})

exp.use(cors()).listen(5000, () => console.log("RUNNING...."));

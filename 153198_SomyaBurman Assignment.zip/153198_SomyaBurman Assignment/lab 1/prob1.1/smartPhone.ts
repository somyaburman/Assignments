/// <reference path = "mobile.ts" />
namespace prob1{

export class smartPhone extends mobile
{
    mobType:string;
    constructor(mobId:number, mobName:string,mobCost:number,mobType:string)
    {
        super(mobId, mobName,mobCost);
        this.mobType=mobType;
    }
    
}
}


var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var prob1;
(function (prob1) {
    var mobile = /** @class */ (function () {
        function mobile(mobId, mobName, mobCost) {
            this.mobId = mobId;
            this.mobName = mobName;
            this.mobCost = mobCost;
        }
        mobile.prototype.printMobileDetails = function () {
            console.log(this.mobId, this.mobCost, this.mobName);
        };
        return mobile;
    }());
    prob1.mobile = mobile;
})(prob1 || (prob1 = {}));
/// <reference path = "mobile.ts" />
var prob1;
(function (prob1) {
    var basicPhone = /** @class */ (function (_super) {
        __extends(basicPhone, _super);
        function basicPhone(mobId, mobName, mobCost, mobType) {
            var _this = _super.call(this, mobId, mobName, mobCost) || this;
            _this.mobType = mobType;
            return _this;
        }
        return basicPhone;
    }(prob1.mobile));
    prob1.basicPhone = basicPhone;
})(prob1 || (prob1 = {}));
/// <reference path = "mobile.ts" />
var prob1;
(function (prob1) {
    var smartPhone = /** @class */ (function (_super) {
        __extends(smartPhone, _super);
        function smartPhone(mobId, mobName, mobCost, mobType) {
            var _this = _super.call(this, mobId, mobName, mobCost) || this;
            _this.mobType = mobType;
            return _this;
        }
        return smartPhone;
    }(prob1.mobile));
    prob1.smartPhone = smartPhone;
})(prob1 || (prob1 = {}));
/// <reference path = "mobile.ts" />
/// <reference path = "basicMobile.ts" />
/// <reference path = "smartPhone.ts" />
var s1 = new prob1.smartPhone(21, "sss", 555, "kjkj");
s1.printMobileDetails();

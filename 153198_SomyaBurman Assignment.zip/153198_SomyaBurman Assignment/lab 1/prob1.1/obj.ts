/// <reference path = "mobile.ts" />
/// <reference path = "basicMobile.ts" />
/// <reference path = "smartPhone.ts" />

var s1= new prob1.smartPhone(21,"sss",555,"kjkj");
s1.printMobileDetails();
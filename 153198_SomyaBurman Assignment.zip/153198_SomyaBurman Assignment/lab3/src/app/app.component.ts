import { Component, OnInit} from '@angular/core';
import {FormGroup, Validators, FormBuilder} from '@angular/forms';
import {NgForm} from '@angular/forms';

@Component({
 selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  productForm:FormGroup;
  pId:number;
  pName:string="";
  pCost:number;
  pOnline:string="";
  pCategory:string="";
  available:string="";
  constructor( private frmBuilder : FormBuilder) { 
    this.productForm = frmBuilder.group({
      pId: ['',Validators.compose([Validators.required,Validators.maxLength(4)])],
      pName: ['',[Validators.required,Validators.maxLength(19)]],
      pCost: ['',Validators.required],
      pOnline:['',Validators.required],
      pCategory: ['',Validators.required],
      available: ['',Validators.required]
    });
  }
  ngOnInit(){

  }

  onSubmit(prodForm:NgForm) {
    
    console.log(this.productForm.value);
  }
}

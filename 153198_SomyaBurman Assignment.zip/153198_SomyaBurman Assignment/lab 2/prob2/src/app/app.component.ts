import { Component } from '@angular/core';
import { NgModule} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  empid:number;
  empname:string;
  empsal:number;
  empdept:string;
  i:number;
  empid1:number;
  empname1:string;
  empsal1:number;
  empdept1:string;
  title = 'app';

 empArray : any[] = [
                   {"empId":1001,"empName":"Rahul","empSal":9000,"empDep":"Java"},
                   {"empId":1002,"empName":"Sachin","empSal":19000,"empDep":"OraApps"},
                   {"empId":1003,"empName":"Vikash","empSal":29000,"empDep":"BI"},

 ];

 addEmp():void
 {
    this.empArray.push({empId:this.empid,empName:this.empname,empSal:this.empsal, empDep:this.empdept});
 }

 
 update(i){
    this.i=i;
    this.empid1=this.empArray[i].empId;
    this.empname1=this.empArray[i].empName;
    this.empsal1=this.empArray[i].empSal;
    this.empdept1=this.empArray[i].empDep;
  
 }
 
 updateemp(i){
   this.empArray[this.i]={
     empId:this.empid1,
     empName:this.empname1,
     empSal:this.empsal1,
     empDep:this.empdept1
   }
   document.getElementById("status").innerHTML="Data Updated";
 }


 deleterow(i){
    this.empArray.splice(i,1);
    document.getElementById("status").innerHTML="Data Deleted";
 }
  

}

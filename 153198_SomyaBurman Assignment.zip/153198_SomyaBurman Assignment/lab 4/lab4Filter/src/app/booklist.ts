export interface BookList
{
    ID:number,
    Name:string,
    Author:String,
    Year:number
}
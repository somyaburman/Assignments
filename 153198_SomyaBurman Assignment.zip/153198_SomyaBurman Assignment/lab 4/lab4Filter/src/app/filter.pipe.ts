import { Pipe, PipeTransform } from '@angular/core';
import {BookList} from './booklist'

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(items: any, arg1: any, arg2:any): any[] {
    if(!items||!arg1)
    return items;
    else
    {
      return items.filter(items=>items[arg2].toString().toLocaleLowerCase().indexOf(arg1.toLowerCase())!==-1);
    }
  }

}

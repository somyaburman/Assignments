import { Component } from '@angular/core';
import { HttpErrorResponse, HttpClientModule, HttpClient} from '@angular/common/http';
import { FilterPipe} from './filter.pipe';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Fetching Data from JSON';
  constructor(private httpService : HttpClient){}
  arrBooks: string[];

 ngOnInit(){
this.httpService.get('./assets/booklist.json').subscribe(
  data=>{
    this.arrBooks = data as string[];
  },
  (err: HttpErrorResponse) => {
        console.log (err.message);
      }
  
);
}

}

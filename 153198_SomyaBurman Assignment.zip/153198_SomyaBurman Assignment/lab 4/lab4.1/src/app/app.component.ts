import { Component } from '@angular/core';
import { NgModule } from '@angular/core';
import { HttpClientModule,  HttpClient, HttpErrorResponse } from '@angular/common/http';




@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'app';

constructor(private http: HttpClient){}

arrBooks: string [];

ngOnInit(){
this.http.get('./assets/booklist.json').subscribe(
  data=>{
    this.arrBooks = data as string[];
  },
  (err: HttpErrorResponse) => {
        console.log (err.message);
      }
  
);
}

}

function nwindow()
{
  var widthobj= document.getElementById("windowWidth");
  var width=widthobj.value;
  var heightobj= document.getElementById("windowHeight");
  var height=heightobj.value;
  var myWindow1= window.open("Prob 2.html","MyCgWindow1","width="+width+",height="+height);
/*TODO: get the height, width, left and top from the form object and pass the values to open method of window along with the name of the html file to be opened in the new window.*/
}
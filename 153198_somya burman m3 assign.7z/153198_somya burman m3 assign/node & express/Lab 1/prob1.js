var empArr=['Ramesh','Suresh','Mahesh','Kamlesh','Paresh','Deepesh'];  
    for( i in empArr)
    {
        console.log(empArr[i])
    }



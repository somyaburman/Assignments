import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import Parent from './parent';

ReactDOM.render(  <div>
        <Parent/>
    </div>
    , document.getElementById('root'));
registerServiceWorker();

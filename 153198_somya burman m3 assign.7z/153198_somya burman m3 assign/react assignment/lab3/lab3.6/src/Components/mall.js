import React, { Component } from 'react';

import Theatre from './theatre'

class Mall extends Component {
    render() { 
        return ( <Theatre /> );
    }
}
 
export default Mall;